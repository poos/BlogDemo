//: Playground - noun: a place where people can play

import UIKit

let john = Person(name: "John", age: 24, gender: .male)
let jane = Person(name: "Jane", age: 33, gender: .female)

//john == jane
//john == john
